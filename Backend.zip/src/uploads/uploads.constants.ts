export const S3_CLIENT = 'S3_CLIENT';
