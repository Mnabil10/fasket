import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { SettingsService } from './settings.service';

@ApiTags('Settings')
@Controller({ path: 'settings', version: ['1'] })
export class SettingsController {
  constructor(private readonly settings: SettingsService) {}

  @Get('delivery-zones')
  async getActiveDeliveryZones() {
    const zones = await this.settings.getActiveDeliveryZones();
    return zones;
  }

  @Get('app')
  async getAppSettings() {
    const [settings, delivery, loyalty] = await Promise.all([
      this.settings.getSettings(),
      this.settings.getDeliveryConfig(),
      this.settings.getLoyaltyConfig(),
    ]);
    return {
      store: {
        name: settings.storeName,
        nameAr: settings.storeNameAr ?? undefined,
        description: settings.storeDescription ?? undefined,
        descriptionAr: settings.storeDescriptionAr ?? undefined,
        contactEmail: settings.contactEmail ?? undefined,
        contactPhone: settings.contactPhone ?? undefined,
        address: settings.storeAddress ?? undefined,
        currency: settings.currency,
        timezone: settings.timezone,
        language: settings.language,
        maintenanceMode: settings.maintenanceMode ?? false,
      },
      delivery,
      loyalty,
      payment: settings.payment ?? undefined,
      notifications: settings.notifications ?? undefined,
      businessHours: settings.businessHours ?? undefined,
    };
  }
}
