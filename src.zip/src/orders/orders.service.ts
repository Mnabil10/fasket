import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService, private notify: NotificationsService) {}

  list(userId: string) {
    return this.prisma.order.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: { id: true, totalCents: true, status: true, createdAt: true }
    });
  }

  detail(userId: string, id: string) {
    return this.prisma.order.findFirst({
      where: { id, userId },
      include: { items: true, address: true }
    });
  }

  async create(userId: string, payload: { addressId: string; paymentMethod: 'COD'|'CARD' }) {
    return this.prisma.$transaction(async (tx) => {
      const cart = await tx.cart.findUnique({ where: { userId }, include: { items: true } });
      if (!cart || cart.items.length === 0) throw new BadRequestException('Empty cart');

      // stock checks
      for (const it of cart.items) {
        const p = await tx.product.findUnique({ where: { id: it.productId } });
        if (!p || p.stock < it.qty) throw new BadRequestException('Insufficient stock for ' + it.productId);
      }

      // decrement stock
      for (const it of cart.items) {
        await tx.product.update({ where: { id: it.productId }, data: { stock: { decrement: it.qty } } });
      }

      const address = await tx.address.findUnique({ where: { id: payload.addressId } });
      const subtotal = cart.items.reduce((s, i) => s + i.priceCents * i.qty, 0);
      const setting = await tx.setting.findFirst();
      const shipping = setting?.deliveryFeeCents ?? 0;
      const discount = 0;
      const total = subtotal + shipping - discount;

      const order = await tx.order.create({
        data: {
          userId,
          status: 'PENDING',
          paymentMethod: payload.paymentMethod as any,
          subtotalCents: subtotal,
          shippingFeeCents: shipping,
          discountCents: discount,
          totalCents: total,
          addressId: address?.id,
          items: {
            create: cart.items.map(i => ({
              productId: i.productId,
              productNameSnapshot: '', // can be filled by join if needed
              priceSnapshotCents: i.priceCents,
              qty: i.qty,
            })),
          },
        },
      });

      await tx.cartItem.deleteMany({ where: { cartId: cart.id } });

      await this.notify.enqueueOrderStatusPush(order.id, 'PENDING');
      return order;
    });
  }
}
