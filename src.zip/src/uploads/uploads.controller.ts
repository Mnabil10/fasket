import {
  BadRequestException, Controller, Get, Post, Query,
  UploadedFile, UseGuards, UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';
import { UploadsService } from './uploads.service';
import { JwtAuthGuard } from '../auth/jwt.guard';
import { AdminGuard } from '../admin/_admin-guards';
import { Express } from 'express';

@ApiTags('Admin/Uploads')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, AdminGuard)
@Controller('api/v1/admin/uploads')
export class UploadsController {
  constructor(private readonly uploads: UploadsService) {}

  @Get('signed-url')
  @ApiQuery({ name: 'filename', required: true })
  @ApiQuery({ name: 'contentType', required: true, enum: ['image/jpeg','image/png','image/webp'] })
  @ApiOkResponse({ description: 'Returns presigned PUT URL and final public URL' })
  async signedUrl(@Query('filename') filename?: string, @Query('contentType') contentType?: string) {
    if (!filename || !contentType) throw new BadRequestException('filename and contentType are required');
    return this.uploads.createSignedUrl({ filename, contentType });
  }

  @Post()
  @UseInterceptors(FileInterceptor('file', {
    storage: memoryStorage(),
    limits: { fileSize: Number(process.env.UPLOAD_MAX_BYTES || 10 * 1024 * 1024) },
    fileFilter: (req, file, cb) => {
      const allowed = String(process.env.UPLOAD_ALLOWED_MIME || 'image/jpeg,image/png,image/webp')
        .split(',').map(s => s.trim());
      if (!allowed.includes(file.mimetype)) return cb(new BadRequestException('Unsupported content type') as any, false);
      cb(null, true);
    },
  }))
  @ApiOkResponse({ description: 'Uploads a file and returns its public URL' })
  async multipart(@UploadedFile() file: Express.Multer.File) {
    return this.uploads.uploadBuffer(file);
  }
}
