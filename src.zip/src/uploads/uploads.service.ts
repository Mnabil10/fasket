import { Inject, Injectable, BadRequestException } from '@nestjs/common';
import { PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { lookup as mimeLookup } from 'mime-types';
import { randomUUID } from 'crypto';
import { Express } from 'express';
import { S3_CLIENT } from './uploads.constants';

function safeFilename(name: string) {
  const [base, ext = ''] = name.split(/\.(?=[^\.]+$)/);
  const slug = base.toLowerCase().replace(/[^\w\-]+/g, '-').replace(/-+/g, '-').slice(0, 64);
  return ext ? `${slug}.${ext.toLowerCase()}` : slug;
}
function todayPath() {
  const d = new Date();
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
}

@Injectable()
export class UploadsService {
  private readonly bucket = process.env.S3_BUCKET!;
  private readonly publicBase = (process.env.S3_PUBLIC_BASE_URL || '').replace(/\/$/, '');
  private readonly ttl = Number(process.env.UPLOAD_PRESIGN_TTL || 300);
  private readonly allowed = new Set(
    String(process.env.UPLOAD_ALLOWED_MIME || 'image/jpeg,image/png,image/webp')
      .split(',').map(s => s.trim()).filter(Boolean),
  );
  private readonly maxBytes = Number(process.env.UPLOAD_MAX_BYTES || 10 * 1024 * 1024);

  constructor(@Inject(S3_CLIENT) private readonly s3: S3Client) {}  // ⬅️ inject string token

  private validateMime(contentType: string) {
    if (!this.allowed.has(contentType)) throw new BadRequestException(`Unsupported content type: ${contentType}`);
  }
  private buildKey(filename: string) {
    const clean = safeFilename(filename || 'file');
    return `products/${todayPath()}/${randomUUID()}-${clean}`;
  }
  private publicUrl(key: string) {
    return this.publicBase ? `${this.publicBase}/${key}` : `https://${this.bucket}.s3.amazonaws.com/${key}`;
  }

  async createSignedUrl(params: { filename: string; contentType: string }) {
    this.validateMime(params.contentType);
    const Key = this.buildKey(params.filename);
    const cmd = new PutObjectCommand({ Bucket: this.bucket, Key, ContentType: params.contentType });
    const uploadUrl = await getSignedUrl(this.s3, cmd, { expiresIn: this.ttl });
    return { uploadUrl, publicUrl: this.publicUrl(Key) };
  }

  async uploadBuffer(file: Express.Multer.File) {
    if (!file) throw new BadRequestException('File is required');
    if (file.size > this.maxBytes) throw new BadRequestException('File too large');
    const mime = file.mimetype || mimeLookup(file.originalname) || 'application/octet-stream';
    this.validateMime(String(mime));
    const Key = this.buildKey(file.originalname);
    await this.s3.send(new PutObjectCommand({ Bucket: this.bucket, Key, Body: file.buffer, ContentType: String(mime) }));
    return { url: this.publicUrl(Key) };
  }
}
