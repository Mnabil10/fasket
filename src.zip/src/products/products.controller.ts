import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiQuery, ApiTags } from '@nestjs/swagger';
import { ProductsService } from './products.service';

@ApiTags('Products')
@ApiBearerAuth() 
@Controller('products')
export class ProductsController {
  constructor(private service: ProductsService) {}

  @Get()
  @ApiQuery({ name: 'q', required: false })
  @ApiQuery({ name: 'categoryId', required: false })
  @ApiQuery({ name: 'min', required: false })
  @ApiQuery({ name: 'max', required: false })
  list(@Query('q') q?: string, @Query('categoryId') categoryId?: string, @Query('min') min?: number, @Query('max') max?: number) {
    return this.service.list({ q, categoryId, min: min ? Number(min) : undefined, max: max ? Number(max) : undefined });
  }

  @Get(':idOrSlug')
  one(@Param('idOrSlug') idOrSlug: string) {
    return this.service.one(idOrSlug);
  }
}
