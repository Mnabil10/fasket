import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  list(q: { q?: string; categoryId?: string; min?: number; max?: number; status?: string }) {
    const where: any = { deletedAt: null };
    if (q?.status) where.status = q.status as any;
    if (q?.categoryId) where.categoryId = q.categoryId;
    if (q?.q) where.OR = [
      { name: { contains: q.q, mode: 'insensitive' } },
      { slug: { contains: q.q, mode: 'insensitive' } },
    ];
    if (q?.min || q?.max) {
      where.priceCents = {};
      if (q.min) where.priceCents.gte = q.min;
      if (q.max) where.priceCents.lte = q.max;
    }
    return this.prisma.product.findMany({
      where,
      select: {
        id: true, name: true, slug: true, imageUrl: true,
        priceCents: true, salePriceCents: true, stock: true, status: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  one(idOrSlug: string) {
    const where = idOrSlug.length === 25 ? { id: idOrSlug } : { slug: idOrSlug };
    return this.prisma.product.findFirst({
      where: { ...where, deletedAt: null },
      include: { category: { select: { id: true, name: true, slug: true } } },
    });
  }
}
