import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AdminOnly } from './_admin-guards';
import { AdminService } from './admin.service';
import { CreateProductDto, ProductListQueryDto, UpdateProductDto } from './dto/product.dto';
import { PaginationDto } from './dto/pagination.dto';

@ApiTags('Admin/Products')
@ApiBearerAuth()
@AdminOnly()
@Controller('admin/products')
export class AdminProductsController {
  constructor(private svc: AdminService) {}

  @Get()
  @ApiQuery({ name: 'q', required: false })
  @ApiQuery({ name: 'categoryId', required: false })
  @ApiQuery({ name: 'status', required: false, enum: ['DRAFT','ACTIVE','HIDDEN','DISCONTINUED'] })
  @ApiQuery({ name: 'minPriceCents', required: false, schema: { type: 'integer' } })
  @ApiQuery({ name: 'maxPriceCents', required: false, schema: { type: 'integer' } })
  @ApiQuery({ name: 'inStock', required: false, schema: { type: 'boolean' } })
  @ApiQuery({ name: 'orderBy', required: false, enum: ['createdAt','priceCents','name'] })
  @ApiQuery({ name: 'sort', required: false, enum: ['asc','desc'] })
  @ApiOkResponse({ description: 'Paginated products' })
  async list(@Query() q: ProductListQueryDto, @Query() page: PaginationDto) {
    const where: any = { deletedAt: null };
    if (q.q) where.OR = [
      { name: { contains: q.q, mode: 'insensitive' } },
      { slug: { contains: q.q, mode: 'insensitive' } },
    ];
    if (q.categoryId) where.categoryId = q.categoryId;
    if (q.status) where.status = q.status;
    if (q.minPriceCents || q.maxPriceCents) {
      where.priceCents = {};
      if (q.minPriceCents) where.priceCents.gte = q.minPriceCents;
      if (q.maxPriceCents) where.priceCents.lte = q.maxPriceCents;
    }
    if (q.inStock !== undefined) where.stock = q.inStock ? { gt: 0 } : 0;

    const orderBy = q.orderBy ?? 'createdAt';
    const sort = q.sort ?? 'desc';

    const [items, total] = await this.svc.prisma.$transaction([
      this.svc.prisma.product.findMany({
        where,
        orderBy: { [orderBy]: sort },
        skip: page.skip, take: page.take,
      }),
      this.svc.prisma.product.count({ where }),
    ]);
    return { items, total, page: page.page, pageSize: page.pageSize };
  }

  @Get(':id')
  one(@Param('id') id: string) {
    return this.svc.prisma.product.findUnique({ where: { id } });
  }

  @Post()
  async create(@Body() dto: CreateProductDto) {
    if (!dto.slug && dto.name) dto.slug = dto.name.toLowerCase().replace(/\s+/g,'-');
    return this.svc.prisma.product.create({ data: dto });
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateProductDto) {
    return this.svc.prisma.product.update({ where: { id }, data: dto });
  }

  // Soft delete (keeps order history consistent)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.svc.prisma.product.update({ where: { id }, data: { deletedAt: new Date() } });
    return { ok: true };
  }
}
