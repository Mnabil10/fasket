import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AdminOnly } from './_admin-guards';
import { AdminService } from './admin.service';
import { CategoryQueryDto, CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';
import { PaginationDto, SortDto } from './dto/pagination.dto';

@ApiTags('Admin/Categories')
@ApiBearerAuth()
@AdminOnly()
@Controller('admin/categories')
export class AdminCategoriesController {
  constructor(private svc: AdminService) {}

  @Get()
  @ApiQuery({ name: 'q', required: false })
  @ApiQuery({ name: 'parentId', required: false })
  @ApiQuery({ name: 'isActive', required: false, schema: { type: 'boolean' } })
  @ApiOkResponse({ description: 'Paginated categories' })
  async list(@Query() q: CategoryQueryDto, @Query() page: PaginationDto, @Query() sort: SortDto) {
    const where: any = {};
    if (q.q) where.name = { contains: q.q, mode: 'insensitive' };
    if (q.parentId) where.parentId = q.parentId;
    if (q.isActive !== undefined) where.isActive = q.isActive;
    // deletedAt is soft-delete flag
    where.deletedAt = null;

    const [items, total] = await this.svc.prisma.$transaction([
      this.svc.prisma.category.findMany({
        where,
        orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
        skip: page.skip, take: page.take,
      }),
      this.svc.prisma.category.count({ where }),
    ]);
    return { items, total, page: page.page, pageSize: page.pageSize };
  }

  @Get(':id')
  async one(@Param('id') id: string) {
    return this.svc.prisma.category.findUnique({ where: { id } });
  }

  @Post()
  async create(@Body() dto: CreateCategoryDto) {
    if (!dto.slug && dto.name) dto.slug = dto.name.toLowerCase().replace(/\s+/g,'-');
    return this.svc.prisma.category.create({ data: dto });
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateCategoryDto) {
    return this.svc.prisma.category.update({ where: { id }, data: dto });
  }

  // Soft delete: sets deletedAt, keeps referential integrity
  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.svc.prisma.category.update({ where: { id }, data: { deletedAt: new Date() } });
    return { ok: true };
  }
}
